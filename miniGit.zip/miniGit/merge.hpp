#pragma once
#include <string>

void mergeBranches(const std::string& ourHash, const std::string& theirHash);