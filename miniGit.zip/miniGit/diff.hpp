#pragma once
#include <string>
void diffCommits(const std::string& hash1, const std::string& hash2);