// miniGit.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <iostream>
#include "merge.hpp"
#include "diff.hpp"


int main() {
    std::cout << "[MERGING BRANCHES]\n";
    mergeBranches("C", "E");

    std::cout << "\n[DIFF VIEWER]\n";
    diffCommits("C", "E");

    return 0;
}

